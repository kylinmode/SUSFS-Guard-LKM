#!/system/bin/sh
# 开机加载 SUSFS 内核模块（vermagic 不一致时由 ksud 自动改写后重试）
KO=$(ls /data/adb/susfs_guard_lkm-*.ko 2>/dev/null | head -1)
if [ -z "$KO" ] && [ -n "$MODDIR" ]; then
  SRC=$(ls "$MODDIR"/susfs_guard_lkm-*.ko 2>/dev/null | head -1)
  if [ -n "$SRC" ]; then
    KO=/data/adb/$(basename "$SRC")
    cp -f "$SRC" "$KO"; chmod 644 "$KO"
  fi
fi
[ -n "$KO" ] || exit 0
[ -d /sys/module/susfs_guard_lkm ] && exit 0

for KSUD in /data/adb/ksu/bin/ksud /data/adb/ssu/bin/ksud /data/adb/ksud; do
  if [ -x "$KSUD" ]; then
    "$KSUD" insmod "$KO" 2>/dev/null && exit 0
  fi
done

insmod "$KO" 2>/dev/null
exit 0
