#!/system/bin/sh
# 安装阶段：把 ko 复制到 /data/adb/
KO=$(ls "$MODPATH"/susfs_guard_lkm-*.ko 2>/dev/null | head -1)
[ -n "$KO" ] || { ui_print "!! 模块内缺少 ko"; abort; }
TARGET=/data/adb/$(basename "$KO")
cp -f "$KO" "$TARGET"
chmod 644 "$TARGET"
ui_print "[*] 已复制 $(basename "$KO") 到 /data/adb/"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/customize.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
